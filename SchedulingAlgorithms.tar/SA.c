#include<stdio.h>
#include<string.h>

#define N 10 
 
typedef struct 
{ 
    int process_id, a_time, b_time, priority;
    int q, ready; 
      
}process_structure; 
 
int Queue(int t1) 
{ 
      if(t1 == 0 || t1 == 1 || t1 == 2 || t1 == 3) 
      { 
            return 1; 
      } 
      else
      {
            return 2; 
      }
} 
 
int main()
{
 
 int n,n1,a[10],b[10],t[10],w[10],g[10],i,j,m,process[10], total=0, wtime[10], ptime[10], temp, ptemp,x[10],smallest,count=0,time;
        float att=0,awt=0,avg=0,tt=0,end;
        char p[10][5],tem[10];
	int pt[10],wt[10],pr[10],temp1;
        int  temp_process, y; 
	process_structure tempp;
        int  x1, time_quantum,wait_time = 0, turnaround_time = 0, arrival_time[10], burst_time[10]; 
       
	  
	  
do{
  printf("*************Scheduling Algorithms*************\n");
  printf("    Please Choose an Algorithm \n");
  printf(" 1. First Come First Serve Algorithm \n");
  printf(" 2. Shortest Job First Algorithm     \n");
  printf(" 3. Shortest Remaining Time First Algorithm\n");
  printf(" 4. Priority Scheduling Algorithm    \n");
  printf(" 5. Round Robin Scheduling Algorithm\n");
  printf(" 6. Virtual Round Robin Scheduling Algorithm\n");
  printf(" 7. Multilevel Queue Scheduling Algorithm   \n");
  printf(" 8. Exit \n");

  scanf("%d",&n);
  switch(n)

  {
   case 1:
        
	for(i=0;i<10;i++)
	{
	a[i]=0; b[i]=0; w[i]=0; g[i]=0;
	}
	printf("enter the number of process:\n");
	scanf("%d",&n1);
	printf("enter the arrival times:\n");
	for(i=0;i<n1;i++)
	scanf("%d",&a[i]);
	printf("enter the burst times:\n");
	for(i=0;i<n1;i++)
	scanf("%d",&b[i]);
	g[0]=0;
	for(i=0;i<10;i++)
	g[i+1]=g[i]+b[i];
	for(i=0;i<n1;i++)
	{
		w[i]=g[i]-a[i];
		t[i]=g[i+1]-a[i];
		awt=awt+w[i];
		att=att+t[i];
	}
	awt =awt/n1;
	att=att/n1;
	printf("\n\tprocess\t A_time\t B_time\t W_time\t TA_time\n");
	for(i=0;i<n1;i++)
	{
	  printf("\tp%d\t%d\t%d\t%d\t%d\n",i,a[i],b[i],w[i],t[i]);
	}
	printf("the average waiting time is :%f\n",awt);
	printf("the average turn around time is :%f\n",att);
        break;
       
    case 2:
	    
	    printf("\nEnter number of Processes:");
	    scanf("%d", &n1);
	    for(i=0;i<n1;i++)
	    {
		printf("\nEnter Process %d ID:",i+1);
		scanf("%d", &process[i]);
		printf("\nEnter Process %d Time:",i+1);
		scanf("%d",&ptime[i]);
	    }
	 
	    for(i=0;i<n1-1;i++)
	    {
		for(j=i+1;j<n1;j++)
		{
		    if(ptime[i]>ptime[j])
		    {
		        temp = ptime[i];
		        ptime[i] = ptime[j];
		        ptime[j] = temp;
		        ptemp = process[i];
		        process[i] = process[j];
		        process[j] = ptemp;
		    }
		}
	    }
		wtime[0]=0;
	    for(i=1;i<n1;i++)
	    {
		wtime[i]=wtime[i-1]+ptime[i-1];
		total=total+wtime[i];
	    }
	    avg=(float)total/n1;
	    printf("\nP_ID\t P_TIME\t W_TIME\n");
	    for(i=0;i<n1;i++)
		printf("%d\t %d\t %d\n",process[i],ptime[i],wtime[i]);
	    printf("\nTotal Waiting Time: %d \nAverage Waiting Time: %f", total, avg);
            break;

     case 3:

         printf("enter the number of Processes:\n");
	 scanf("%d",&n1); 
	 printf("enter arrival time\n");
	 for(i=0;i<n1;i++)
	 scanf("%d",&a[i]);
	 printf("enter burst time\n");
	 for(i=0;i<n1;i++)
	 scanf("%d",&b[i]); 
	 for(i=0;i<n1;i++)
	 x[i]=b[i];

	  b[9]=9999;
	  
	 for(time=0;count!=n1;time++)
	 {
	   smallest=9;
	  for(i=0;i<n1;i++)
	  {
	   if(a[i]<=time && b[i]<b[smallest] && b[i]>0 )
	   smallest=i;
	  }
	  b[smallest]--;
	  if(b[smallest]==0)
	  {
	   count++;
	   end=time+1;
	   avg=avg+end-a[smallest]-x[smallest];
	   tt= tt+end-a[smallest];
	  }
	 }
	  printf("\n\nAverage waiting time = %lf\n",avg/n1);
	  printf("Average Turnaround time = %lf\n",tt/n1);
          break;

       case 4:
          
	 
	  printf("enter no of processes:");
	  scanf("%d",&n1);
	  for(i=0;i<n1;i++)
	  {
	  printf("enter process%d ID:",i+1);
	  scanf("%s",&p[i]);
	  printf("enter process time:");
	  scanf("%d",&pt[i]);
	  printf("enter priority:");
	  scanf("%d",&pr[i]);
	  }
	  for(i=0;i<n1-1;i++)
	  {
	     for(j=i+1;j<n1;j++)
	     {
	       if(pr[i]>pr[j])
		{
		   temp1=pr[i];
		   pr[i]=pr[j];
		   pr[j]=temp1;
		   temp1=pt[i];
		   pt[i]=pt[j];
		   pt[j]=temp1;
		   strcpy(tem,p[i]);
		   strcpy(p[i],p[j]);
		   strcpy(p[j],tem);
		}
	     }
	  }
	  wt[0]=0;
	   for(i=1;i<n1;i++)
	   {
	   wt[i]=wt[i-1]+pt[i-1];
	   total=total+wt[i];
	   }
	   avg=(float)total/n1;
	   printf("\n p_name\t p_time\t priority\t w_time\n");
	   for(i=0;i<n1;i++)
	    printf(" %s\t %d\t %d\t %d\n" ,p[i],pt[i],pr[i],wt[i]);
	   printf("total waiting time=%d\n avg waiting time=%f\n",total,avg);
         break;

	 case 5:
	     
	    
	      
	      printf("\nEnter Total Number of Processes:\t"); 
	      scanf("%d", &n1); 
	      x1 = n1; 
	      for(i = 0; i < n1; i++) 
	      {
		    printf("\nEnter Details of Process[%d]\n", i + 1);
		    printf("Arrival Time:\t");
		    scanf("%d", &arrival_time[i]);
		    printf("Burst Time:\t");
		    scanf("%d", &burst_time[i]); 
		    tem[i] = burst_time[i];
	      } 
	      printf("\nEnter Time Quantum:\t"); 
	      scanf("%d", &time_quantum); 
	      printf("\nProcess ID\t\tBurst Time\t Turnaround Time\t Waiting Time\n");
	      for(total = 0, i = 0; x1 != 0;) 
	      { 
		    if(tem[i] <= time_quantum && tem[i] > 0) 
		    { 
		          total = total + tem[i]; 
		          tem[i] = 0; 
		          count = 1; 
		    } 
		    else if(tem[i] > 0) 
		    { 
		          tem[i] = tem[i] - time_quantum; 
		          total = total + time_quantum; 
		    } 
		    if(tem[i] == 0 && count == 1) 
		    { 
		          x1--; 
		          printf("\nProcess[%d]\t\t%d\t\t %d\t\t\t %d", i + 1, burst_time[i], total - arrival_time[i], 
                          total - arrival_time[i]  - burst_time[i]);
		          wait_time = wait_time + total - arrival_time[i] - burst_time[i]; 
		          turnaround_time = turnaround_time + total - arrival_time[i]; 
		          count = 0; 
		    } 
		    if(i == n1 - 1) 
		    {
		          i = 0; 
		    }
		    else if(arrival_time[i + 1] <= total) 
		    {
		          i++;
		    }
		    else 
		    {
		          i = 0;
		    }
	      } 
	      avg = wait_time * 1.0 / n1;
	      tt= tt * 1.0 / n1;
	      printf("\n\nAverage Waiting Time:\t%f\n", avg); 
	      printf("\nAvg Turnaround Time:\t%f\n", tt);  
              break;
       case 6:

                  break;

       case 7:
           
	      
	      printf("Enter Total Number of Processes:\t"); 
	      scanf("%d", &n1);  
	      process_structure process[n1]; 
	      for(count = 0; count < n1; count++) 
	      { 
		    printf("\nProcess ID:\t"); 
		    scanf("%d", &process[count].process_id); 
		    printf("Arrival Time:\t"); 
		    scanf("%d", &process[count].a_time); 
		    printf("Burst Time:\t"); 
		    scanf("%d", &process[count].b_time); 
		    printf("Process Priority:\t"); 
		    scanf("%d", &process[count].priority); 
		    temp_process = process[count].priority; 
		    process[count].q = Queue(temp_process);
		    process[count].ready = 0; 
	      }
	      time = process[0].b_time; 
	      for(y = 0; y < n1; y++) 
	      { 
		    for(count = y; count < n1; count++) 
		    { 
		          if(process[count].a_time < time) 
		          {
		                process[count].ready = 1; 
		          } 
		    } 
		    for(count = y; count < n1 - 1; count++) 
		    {
		          for(j = count + 1; j < n1; j++) 
		          { 
		                if(process[count].ready == 1 && process[j].ready == 1) 
		                { 
		                      if(process[count].q == 2 && process[j].q == 1) 
		                      { 
		                            tempp = process[count]; 
		                            process[count] = process[j]; 
		                            process[j] = tempp; 
		                      } 
		                } 
		          } 
		    } 
		    for(count = y; count < n1 - 1; count++) 
		    { 
		          for(j = count + 1; j < n1; j++) 
		          {
		                if(process[count].ready == 1 && process[j].ready == 1) 
		                { 
		                      if(process[count].q == 1 && process[j].q == 1) 
		                      { 
		                            if(process[count].b_time > process[j].b_time) 
		                            { 
		                                  tempp = process[count]; 
		                                  process[count] = process[j]; 
		                                  process[j] = tempp; 
		                            } 
		                            else 
		                            { 
		                                  break; 
		                            } 
		                      } 
		                } 
		          } 
		    } 
		    printf("\nProcess[%d]:\tTime:\t%d To %d\n", process[y].process_id, time, time + process[y].b_time); 
		    time = time + process[y].b_time; 
		    for(count = y; count < n1; count++) 
		    { 
		          if(process[count].ready == 1) 
		          { 
		                process[count].ready = 0; 
		          } 
		    } 
	      } 

              break;

        
  }
 }while(n!=8);
        return 0;
}
